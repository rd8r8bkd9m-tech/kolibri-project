#!/bin/bash

# Тест всех Kolibri архиваторов
# Реальный файл: test_1mb.bin (1 MB)

TEST_FILE="/Users/kolibri/Documents/test_1mb.bin"
OUTPUT_DIR="/Users/kolibri/Documents/os/test_results"
TOOLS_DIR="/Users/kolibri/Documents/os/tools"

mkdir -p "$OUTPUT_DIR"

echo "════════════════════════════════════════════════════════════"
echo "  ТЕСТИРОВАНИЕ ВСЕХ KOLIBRI АРХИВАТОРОВ"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "📄 Тестовый файл: $TEST_FILE"
ls -lh "$TEST_FILE"
echo ""

# Для сравнения: GZIP
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 GZIP (для сравнения)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
time gzip -c "$TEST_FILE" > "$OUTPUT_DIR/test.gz"
ls -lh "$OUTPUT_DIR/test.gz"
echo ""

cd "$TOOLS_DIR"

# Компилируем все архиваторы
echo "🔧 Компиляция архиваторов..."
gcc -O3 -o kolibri_real kolibri_archiver_real.c -lm 2>/dev/null
gcc -O3 -o kolibri_v3 kolibri_archiver_v3.c -lm 2>/dev/null
gcc -O3 -o kolibri_v4 kolibri_archiver_v4.c -lm 2>/dev/null
gcc -O3 -o kolibri_v10 kolibri_archiver_v10.c -lm 2>/dev/null
gcc -O3 -o kolibri_dict kolibri_dictionary_archiver.c -lm 2>/dev/null
gcc -O3 -o kolibri_meta kolibri_meta_archiver.c -lm 2>/dev/null
gcc -O3 -o kolibri_formula kolibri_formula_archiver.c -lm 2>/dev/null
gcc -O3 -o kolibri_fractal kolibri_archiver_fractal.c -lm 2>/dev/null
echo "✅ Компиляция завершена"
echo ""

# Тест 1: kolibri_real
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 1. KOLIBRI REAL (v2.0) - Данные → Цифры → Паттерны"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_real" ]; then
    time ./kolibri_real compress "$TEST_FILE" "$OUTPUT_DIR/test_real.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_real.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_real.kolibri"
    else
        echo "❌ Архив не создан"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Тест 2: kolibri_v3
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 2. KOLIBRI V3 - Мета-компрессия RLE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_v3" ]; then
    time ./kolibri_v3 compress "$TEST_FILE" "$OUTPUT_DIR/test_v3.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_v3.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_v3.kolibri"
    else
        echo "❌ Архив не создан"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Тест 3: kolibri_v4
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 3. KOLIBRI V4 - Adaptive Compression"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_v4" ]; then
    time ./kolibri_v4 compress "$TEST_FILE" "$OUTPUT_DIR/test_v4.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_v4.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_v4.kolibri"
    else
        echo "❌ Архив не создан"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Тест 4: kolibri_v10
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 4. KOLIBRI V10 - Universal Compression"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_v10" ]; then
    time ./kolibri_v10 "$TEST_FILE" "$OUTPUT_DIR/test_v10.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_v10.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_v10.kolibri"
    else
        echo "❌ Архив не создан"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Тест 5: kolibri_dict
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 5. KOLIBRI DICTIONARY - Dictionary-based"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_dict" ]; then
    timeout 60 time ./kolibri_dict compress "$TEST_FILE" "$OUTPUT_DIR/test_dict.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_dict.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_dict.kolibri"
    else
        echo "❌ Архив не создан (timeout или ошибка)"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Тест 6: kolibri_meta
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔹 6. KOLIBRI META - Meta-compression"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
if [ -f "./kolibri_meta" ]; then
    timeout 60 time ./kolibri_meta compress "$TEST_FILE" "$OUTPUT_DIR/test_meta.kolibri" 2>&1 | tail -20
    if [ -f "$OUTPUT_DIR/test_meta.kolibri" ]; then
        ls -lh "$OUTPUT_DIR/test_meta.kolibri"
    else
        echo "❌ Архив не создан (timeout или ошибка)"
    fi
else
    echo "❌ Компиляция не удалась"
fi
echo ""

# Финальное сравнение
echo "════════════════════════════════════════════════════════════"
echo "  📊 ИТОГОВАЯ ТАБЛИЦА РЕЗУЛЬТАТОВ"
echo "════════════════════════════════════════════════════════════"
echo ""
echo "Исходный файл: $(ls -lh "$TEST_FILE" | awk '{print $5}')"
echo ""
ls -lh "$OUTPUT_DIR"/*.gz "$OUTPUT_DIR"/*.kolibri 2>/dev/null | awk '{print $9, $5}' | sed 's|.*/||'
echo ""

# Вычисляем коэффициенты
ORIGINAL_SIZE=$(stat -f%z "$TEST_FILE")
echo "Коэффициенты сжатия:"
for file in "$OUTPUT_DIR"/*.gz "$OUTPUT_DIR"/*.kolibri; do
    if [ -f "$file" ]; then
        SIZE=$(stat -f%z "$file")
        RATIO=$(echo "scale=2; $ORIGINAL_SIZE / $SIZE" | bc)
        BASENAME=$(basename "$file")
        printf "%-30s %.2fx\n" "$BASENAME" "$RATIO"
    fi
done

echo ""
echo "✅ Тестирование завершено!"
