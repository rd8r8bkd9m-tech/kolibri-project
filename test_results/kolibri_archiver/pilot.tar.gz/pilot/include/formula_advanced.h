#ifndef FORMULA_ADVANCED_H
#define FORMULA_ADVANCED_H

#include "formula_core.h"

#endif /* FORMULA_ADVANCED_H */
